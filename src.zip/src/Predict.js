// Predict.js
import React, { useState } from 'react';
import axios from 'axios';

const Predict = () => {
    const [formData, setFormData] = useState({
        pickup_area: '',
        dropoff_area: '',
        day_of_week: '',
        traffic_level: '',
        weather_conditions: '',
        available_seats: 1,
        historical_rides: 0,
        hour_of_day: 0,
        month: 1
    });
    const [prediction, setPrediction] = useState(null);

    const handleChange = e => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = async e => {
        e.preventDefault();
        const token = localStorage.getItem('token');
        try {
            const res = await axios.post('http://localhost:5001/predict', { features: formData }, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setPrediction(res.data.prediction); // Use prediction directly
        } catch (err) {
            console.error(err);
            alert('Error making prediction');
        }
    };
    

    return (
        <div className="container">
            <h2>Predict Route Zone</h2>
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label>Pickup Area</label>
                    <input type="text" name="pickup_area" className="form-control" onChange={handleChange} required />
                </div>
                <div className="mb-3">
                    <label>Dropoff Area</label>
                    <input type="text" name="dropoff_area" className="form-control" onChange={handleChange} required />
                </div>
                <div className="mb-3">
                    <label>Day of Week</label>
                    <select name="day_of_week" className="form-control" onChange={handleChange} required>
                        <option value="" disabled selected>Select Day</option>
                        <option value="Monday">Monday</option>
                        <option value="Tuesday">Tuesday</option>
                        <option value="Wednesday">Wednesday</option>
                        <option value="Thursday">Thursday</option>
                        <option value="Friday">Friday</option>
                        <option value="Saturday">Saturday</option>
                        <option value="Sunday">Sunday</option>
                    </select>
                </div>
                <div className="mb-3">
                    <label>Traffic Level</label>
                    <select name="traffic_level" className="form-control" onChange={handleChange} required>
                        <option value="" disabled selected>Select Traffic Level</option>
                        <option value="Low">Low</option>
                        <option value="Medium">Medium</option>
                        <option value="High">High</option>
                    </select>
                </div>
                <div className="mb-3">
                    <label>Weather Conditions</label>
                    <select name="weather_conditions" className="form-control" onChange={handleChange} required>
                        <option value="" disabled selected>Select Weather</option>
                        <option value="Clear">Clear</option>
                        <option value="Rainy">Rainy</option>
                        <option value="Snowy">Snowy</option>
                    </select>
                </div>
                <div className="mb-3">
                    <label>Available Seats</label>
                    <input type="number" name="available_seats" className="form-control" min="1" max="4" onChange={handleChange} required />
                </div>
                <div className="mb-3">
                    <label>Historical Rides</label>
                    <input type="number" name="historical_rides" className="form-control" min="0" onChange={handleChange} required />
                </div>
                <div className="mb-3">
                    <label>Hour of Day</label>
                    <input type="number" name="hour_of_day" className="form-control" min="0" max="23" onChange={handleChange} required />
                </div>
                <div className="mb-3">
                    <label>Month</label>
                    <input type="number" name="month" className="form-control" min="1" max="12" onChange={handleChange} required />
                </div>
                <button type="submit" className="btn btn-primary">Predict</button>
            </form>
            {prediction !== null && (
                <div className="mt-3">
                    <h4>Carpool Probability: {(prediction * 100).toFixed(2)}%</h4>
                </div>
            )}
        </div>
    );
};

export default Predict;
