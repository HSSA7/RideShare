import React, { useState } from 'react';
import axios from 'axios';

const RideRequest = () => {
    const [formData, setFormData] = useState({
        pickup_location: '',
        dropoff_location: '',
        pickup_time: ''
    });

    const handleChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async e => {
        e.preventDefault();
        const token = localStorage.getItem('token');
        try {
            const res = await axios.post('http://localhost:5001/ride-request', formData, {
                headers: { Authorization: `Bearer ${token}` }
            });
            alert(res.data.message);
        } catch (err) {
            alert('Error creating ride request');
        }
    };

    return (
        <div>
            <h2>Create Ride Request</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="pickup_location" placeholder="Pickup Location" onChange={handleChange} required />
                <input type="text" name="dropoff_location" placeholder="Dropoff Location" onChange={handleChange} required />
                <input type="datetime-local" name="pickup_time" onChange={handleChange} required />
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default RideRequest;
