import React, { useState } from 'react';
import axios from 'axios';

const DrivingSchedule = () => {
    const [formData, setFormData] = useState({
        route: '',
        departure_time: '',
        available_seats: 1
    });

    const handleChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async e => {
        e.preventDefault();
        const token = localStorage.getItem('token');
        try {
            const res = await axios.post('http://localhost:5001/driving-schedule', formData, {
                headers: { Authorization: `Bearer ${token}` }
            });
            alert(res.data.message);
        } catch (err) {
            alert('Error creating driving schedule');
        }
    };

    return (
        <div>
            <h2>Create Driving Schedule</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="route" placeholder="Route" onChange={handleChange} required />
                <input type="datetime-local" name="departure_time" onChange={handleChange} required />
                <input type="number" name="available_seats" min="1" onChange={handleChange} required />
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default DrivingSchedule;
