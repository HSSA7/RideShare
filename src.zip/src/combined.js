import React, { useEffect, useContext } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Map from './Map';
import Register from './Register';
import Login from './Login';
import RideRequest from './RideRequest';
import DrivingSchedule from './DrivingSchedule';
import { SocketContext } from './SocketContext';
import Predict from './Predict';


function App() {
  const socket = useContext(SocketContext);

  useEffect(() => {
    socket.on('new_ride_request', data => {
      alert(data.message);
    });

    socket.on('new_driving_schedule', data => {
      alert(data.message);
    });

    return () => {
      socket.off('new_ride_request');
      socket.off('new_driving_schedule');
    };
  }, [socket]);

  return (
    <Router>
      <div className="App">
        <nav>
          <Link to="/">Map</Link> | <Link to="/register">Register</Link> | <Link to="/login">Login</Link> | <Link to="/ride-request">Ride Request</Link> | <Link to="/driving-schedule">Driving Schedule</Link> |<Link to="/predict">Predict</Link>
        </nav>
        <Routes>
          <Route path="/" element={<Map />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/ride-request" element={<RideRequest />} />
          <Route path="/driving-schedule" element={<DrivingSchedule />} />
          <Route path="/predict" element={<Predict />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
import React, { useState } from 'react';
import axios from 'axios';

const DrivingSchedule = () => {
    const [formData, setFormData] = useState({
        route: '',
        departure_time: '',
        available_seats: 1
    });

    const handleChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async e => {
        e.preventDefault();
        const token = localStorage.getItem('token');
        try {
            const res = await axios.post('http://localhost:5000/driving-schedule', formData, {
                headers: { Authorization: `Bearer ${token}` }
            });
            alert(res.data.message);
        } catch (err) {
            alert('Error creating driving schedule');
        }
    };

    return (
        <div>
            <h2>Create Driving Schedule</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="route" placeholder="Route" onChange={handleChange} required />
                <input type="datetime-local" name="departure_time" onChange={handleChange} required />
                <input type="number" name="available_seats" min="1" onChange={handleChange} required />
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default DrivingSchedule;
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import 'bootstrap/dist/css/bootstrap.min.css';
import { SocketProvider } from './SocketContext';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
   <SocketProvider>
   <App />
   </SocketProvider>
    
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
import React, { useState } from 'react';
import axios from 'axios';

const Login = () => {
    const [formData, setFormData] = useState({
        username: '',
        password: ''
    });

    const handleChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async e => {
        e.preventDefault();
        try {
            const res = await axios.post('http://localhost:5000/login', formData);
            localStorage.setItem('token', res.data.access_token);
            alert('Logged in successfully');
        } catch (err) {
            alert('Invalid credentials');
        }
    };

    return (
        <div>
            <h2>Login</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="username" placeholder="Username" onChange={handleChange} required />
                <input type="password" name="password" placeholder="Password" onChange={handleChange} required />
                <button type="submit">Login</button>
            </form>
        </div>
    );
};

export default Login;

import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

const Map = () => {
    const position = [12.9716, 77.5946]; // Bangalore coordinates

    return (
        <MapContainer center={position} zoom={13} style={{ height: "400px", width: "100%" }}>
            <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution="&copy; OpenStreetMap contributors"
            />
            <Marker position={position}>
                <Popup>
                    Bangalore
                </Popup>
            </Marker>
        </MapContainer>
    );
}

export default Map;
import React, { useState } from 'react';
import axios from 'axios';

const Predict = () => {
    const [features, setFeatures] = useState({});
    const [prediction, setPrediction] = useState(null);

    const handleChange = e => {
        setFeatures({ ...features, [e.target.name]: e.target.value });
    };

    const handleSubmit = async e => {
        e.preventDefault();
        const token = localStorage.getItem('token');
        try {
            const res = await axios.post('http://localhost:5000/predict', { features }, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setPrediction(res.data.prediction);
        } catch (err) {
            alert('Error making prediction');
        }
    };

    return (
        <div>
            <h2>Predict Route Zone</h2>
            <form onSubmit={handleSubmit}>
                {/* Add input fields based on your model's features */}
                <input type="text" name="feature1" placeholder="Feature 1" onChange={handleChange} required />
                <input type="text" name="feature2" placeholder="Feature 2" onChange={handleChange} required />
                {/* Add more features as needed */}
                <button type="submit">Predict</button>
            </form>
            {prediction && <div>Prediction: {prediction}</div>}
        </div>
    );
};

export default Predict;
import React, { useState } from 'react';
import axios from 'axios';

const Register = () => {
    const [formData, setFormData] = useState({
        username: '',
        password: '',
        role: 'Rider'
    });

    const handleChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async e => {
        e.preventDefault();
        try {
            const res = await axios.post('http://localhost:5000/register', formData);
            alert(res.data.message);
        } catch (err) {
            alert('Error registering user');
        }
    };

    return (
        <div className="container">
            <h2>Register</h2>
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <input type="text" name="username" className="form-control" placeholder="Username" onChange={handleChange} required />
                </div>
                <div className="mb-3">
                    <input type="password" name="password" className="form-control" placeholder="Password" onChange={handleChange} required />
                </div>
                <div className="mb-3">
                    <select name="role" className="form-control" onChange={handleChange}>
                        <option value="Rider">Rider</option>
                        <option value="Driver">Driver</option>
                        <option value="Both">Both</option>
                    </select>
                </div>
                <button type="submit" className="btn btn-primary">Register</button>
            </form>
        </div>
    );
};

export default Register;
import React, { useState } from 'react';
import axios from 'axios';

const RideRequest = () => {
    const [formData, setFormData] = useState({
        pickup_location: '',
        dropoff_location: '',
        pickup_time: ''
    });

    const handleChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async e => {
        e.preventDefault();
        const token = localStorage.getItem('token');
        try {
            const res = await axios.post('http://localhost:5000/ride-request', formData, {
                headers: { Authorization: `Bearer ${token}` }
            });
            alert(res.data.message);
        } catch (err) {
            alert('Error creating ride request');
        }
    };

    return (
        <div>
            <h2>Create Ride Request</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="pickup_location" placeholder="Pickup Location" onChange={handleChange} required />
                <input type="text" name="dropoff_location" placeholder="Dropoff Location" onChange={handleChange} required />
                <input type="datetime-local" name="pickup_time" onChange={handleChange} required />
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default RideRequest;
import React, { createContext } from 'react';
import { io } from 'socket.io-client';

export const SocketContext = createContext();

const socket = io('http://localhost:5000');

export const SocketProvider = ({ children }) => {
    return (
        <SocketContext.Provider value={socket}>
            {children}
        </SocketContext.Provider>
    );
};
