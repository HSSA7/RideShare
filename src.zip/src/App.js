import React, { useEffect, useContext } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Map from './Map';
import Register from './Register';
import Login from './Login';
import RideRequest from './RideRequest';
import DrivingSchedule from './DrivingSchedule';
import { SocketContext } from './SocketContext';
import Predict from './Predict';


function App() {
  const socket = useContext(SocketContext);

  useEffect(() => {
    socket.on('new_ride_request', data => {
      alert(data.message);
    });

    socket.on('new_driving_schedule', data => {
      alert(data.message);
    });

    return () => {
      socket.off('new_ride_request');
      socket.off('new_driving_schedule');
    };
  }, [socket]);

  return (
    <Router>
      <div className="App">
        <nav>
          <Link to="/">Map</Link> | <Link to="/register">Register</Link> | <Link to="/login">Login</Link> | <Link to="/ride-request">Ride Request</Link> | <Link to="/driving-schedule">Driving Schedule</Link> |<Link to="/predict">Predict</Link>
        </nav>
        <Routes>
          <Route path="/" element={<Map />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/ride-request" element={<RideRequest />} />
          <Route path="/driving-schedule" element={<DrivingSchedule />} />
          <Route path="/predict" element={<Predict />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
